#用于存储全局变量
QUESTION_DICT = {}